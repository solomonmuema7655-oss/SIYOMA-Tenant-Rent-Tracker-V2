package com.siyoma.tenanttracker;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.appcompat.app.AppCompatActivity;
import androidx.webkit.WebViewAssetLoader;

public class MainActivity extends AppCompatActivity {
    private ValueCallback<Uri[]> fileCallback;
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WebView webView=new WebView(this);
        WebViewAssetLoader loader=new WebViewAssetLoader.Builder().addPathHandler("/assets/",new WebViewAssetLoader.AssetsPathHandler(this)).build();
        webView.setWebViewClient(new WebViewClient(){
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r){return loader.shouldInterceptRequest(r.getUrl());}
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r){
                Uri u=r.getUrl(); String host=u.getHost();
                if(host!=null && (host.equals("wa.me")||host.endsWith("whatsapp.com")||host.equals("api.whatsapp.com"))){
                    try{startActivity(new Intent(Intent.ACTION_VIEW,u));}catch(Exception ignored){}
                    return true;
                }
                return false;
            }
        });
        webView.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams params){
                if(fileCallback!=null)fileCallback.onReceiveValue(null); fileCallback=cb;
                try{Intent i=params.createIntent(); startActivityForResult(i,1001); return true;}catch(Exception e){fileCallback=null; return false;}
            }
        });
        WebSettings s=webView.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(false); s.setAllowContentAccess(true);
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html"); setContentView(webView);
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==1001 && fileCallback!=null){Uri[] r=null;if(resultCode==RESULT_OK&&data!=null){Uri u=data.getData();if(u!=null)r=new Uri[]{u};}fileCallback.onReceiveValue(r);fileCallback=null;}
    }
}
